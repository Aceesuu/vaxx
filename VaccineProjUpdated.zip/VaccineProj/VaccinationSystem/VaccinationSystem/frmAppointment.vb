﻿Public Class frmAppointment
    Private Sub tmr_Click(sender As Object, e As EventArgs) Handles lblTimer.Click
        lblTimer.Text = DateTime.Now
    End Sub
End Class