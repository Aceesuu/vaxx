﻿Imports System.Data
Imports System.Data.SqlClient
Public Class frmLogin
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim con As SqlConnection = New SqlConnection("Data Source=ACE\SQLEXPRESS;Initial Catalog=TBVaccineSystem;Integrated Security=True")
        Dim cmd As SqlCommand = New SqlCommand("SELECT * FROM [dbo].[tblregister] WHERE Username = '" + txtUsername.Text + "' and password ='" + txtPassword.Text + "'", con)
        Dim sda As SqlDataAdapter = New SqlDataAdapter(cmd)
        Dim dt As DataTable = New DataTable()
        sda.Fill(dt)



        If (dt.Rows.Count > 0) Then
            MessageBox.Show("LOGIN SUCESS!", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Else
            MessageBox.Show("ERROR! PLEASE TRY AGAIN!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If



    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        frmHomepage.ShowDialog()
        Me.Hide()
    End Sub

    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click
        frmRegistration.ShowDialog()
        Me.Hide()
    End Sub

    Private Sub btnLoginAdmin_Click(sender As Object, e As EventArgs) Handles btnLoginAdmin.Click
        frmLoginAdmin.Show()
        Me.Hide()
    End Sub

End Class