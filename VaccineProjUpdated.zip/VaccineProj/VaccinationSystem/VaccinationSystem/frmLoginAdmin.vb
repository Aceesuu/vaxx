﻿Public Class frmLoginAdmin
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        If (txtUsername.Text = "ADMIN" And txtPassword.Text = "Group8") Then
            MessageBox.Show("Your Logged in as Admin")
            Me.Hide()
            frmProfileAdmin.Show()
        Else
            MsgBox("Invalid Username or Password")
        End If
    End Sub
End Class
