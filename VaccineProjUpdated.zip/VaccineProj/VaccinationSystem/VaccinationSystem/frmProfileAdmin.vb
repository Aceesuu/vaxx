﻿Public Class frmProfileAdmin
    Public Shared AdminMain

    Private Sub btnRecord_Click(sender As Object, e As EventArgs) Handles btnRecord.Click
        With frmRecord
            .TopLevel = False
            Panel2.Controls.Add(frmRecord)
            .BringToFront()
            .Show()
            frmFacility.Hide()
            frmVaccineBrand.Hide()
            frmVaccinator.Hide()
        End With
    End Sub

    Private Sub btnVaccineBrand_Click(sender As Object, e As EventArgs) Handles btnVaccineBrand.Click
        With frmVaccineBrand
            .TopLevel = False
            Panel2.Controls.Add(frmVaccineBrand)
            .BringToFront()
            .Show()
            frmFacility.Hide()
            frmVaccinator.Hide()
            frmRecord.Hide()
        End With
    End Sub

    Private Sub btnVaccinator_Click(sender As Object, e As EventArgs) Handles btnVaccinator.Click
        With frmVaccinator
            .TopLevel = False
            Panel2.Controls.Add(frmVaccinator)
            .BringToFront()
            .Show()
            frmFacility.Hide()
            frmRecord.Hide()
            frmVaccineBrand.Hide()
        End With
    End Sub

    Private Sub btnFacility_Click(sender As Object, e As EventArgs) Handles btnFacility.Click
        With frmFacility
            .TopLevel = False
            Panel2.Controls.Add(frmFacility)
            .BringToFront()
            .Show()
            frmRecord.Hide()
            frmVaccineBrand.Hide()
            frmVaccinator.Hide()
        End With

    End Sub
End Class