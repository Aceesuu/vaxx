﻿Imports System.Data
Imports System.Data.SqlClient
Public Class frmRecord
    Dim con As New SqlConnection("Data Source=ACE\SQLEXPRESS;Initial Catalog=TBVaccineSystem;Integrated Security=True")
    Dim cmd As New SqlCommand
    Dim da As New SqlDataAdapter
    Dim dset As New DataSet
    Private Sub btnInsert_Click_1(sender As Object, e As EventArgs) Handles btnInsert.Click
        Dim Fname As String = txtFname.Text
        Dim Lname As String = txtLName.Text
        Dim MI As String = txtMidIni.Text
        Dim Birtdate As String = dtpBirthdate.Value.Date
        Dim Gender As String = cboGender.SelectedItem
        Dim Status As String = cboStatus.SelectedItem
        Dim Address As String = txtAddress.Text

        Dim cmd As New SqlCommand("INSERT INTO [dbo].[tblregister]
            
            ([regisid]
           ,[idtype]
           ,[lastname]
           ,[firstname]
           ,[middleini]
           ,[username]
           ,[password]
           ,[birthdate]
           ,[gender]
           ,[priolevel]
           ,[address]
           ,[email]
           ,[contactno])
     VALUES
      ('" + cboTypeID.SelectedItem.ToString + "','" + txtLName.Text + "','" + txtRegID.Text + "','" + txtFname.Text + "','" + txtMidIni.Text + "','" + txtUsername.Text + "','" + txtPass.Text + "','" + dtpBirthdate.Value.Date + "','" + cboGender.SelectedItem.ToString + "','" + cboPriority.SelectedItem.ToString + "','" + txtAddress.Text + "','" + txtEmail.Text + "','" + txtContact.Text + "')", con)
        con.Open()
        cmd.ExecuteNonQuery()
        con.Close()

        txtEmail.Text = ""
        txtAddress.Text = ""
        txtFname.Text = ""
        txtLName.Text = ""
        txtMidIni.Text = ""
        txtUsername.Text = ""
        txtPass.Text = ""
        txtContact.Text = ""
        MessageBox.Show("You successfully inserted data!", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Information)
        BindData()
    End Sub

    Public Sub BindData()
        Dim query As String = "SELECT * FROM [dbo].[tblregister]"
        Using con As New SqlConnection("Data Source=ACE\SQLEXPRESS;Initial Catalog=TBVaccineSystem;Integrated Security=True")
            Using cmd As SqlCommand = New SqlCommand(query, con)
                Using da As New SqlDataAdapter()
                    da.SelectCommand = cmd
                    Using dt As New DataTable()
                        da.Fill(dt)
                        DataGridView1.DataSource = dt
                    End Using
                End Using
            End Using
        End Using
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim Fname As String = txtFname.Text
        Dim Lname As String = txtLName.Text
        Dim MI As String = txtMidIni.Text
        Dim Birtdate As String = dtpBirthdate.Value.Date
        Dim Gender As String = cboGender.SelectedItem
        Dim Status As String = cboStatus.SelectedItem
        Dim Address As String = txtAddress.Text


        Dim con As New SqlConnection("Data Source=ACE\SQLEXPRESS;Initial Catalog=TBVaccineSystem;Integrated Security=True")

        Try
            If MsgBox("Update this record?", vbYesNo + vbQuestion) = vbYes Then
                con.Open()

                Dim cmd As New SqlCommand("UPDATE [dbo].[tblregister] SET 
                
                  
                  idtype = @idtype
                  ,lastname = @lastname
                  ,firstname = @firstname
                  ,middleini = @middleini
                  ,username = @username
                  ,password = @password
                  ,birthdate = @birthdate
                  ,gender = @gender
                  ,priolevel = @priolevel
                  ,address = @address
                  ,email = @email
                  ,contactno = @contactno

                   WHERE regisid = @regisid", con)
                With cmd
                    .Parameters.AddWithValue("@regisid", txtRegID.Text)
                    .Parameters.AddWithValue("@idtype", cboTypeID.Text)
                    .Parameters.AddWithValue("@lastname", txtLName.Text)
                    .Parameters.AddWithValue("@firstname", txtFname.Text)
                    .Parameters.AddWithValue("@middleini", txtMidIni.Text)
                    .Parameters.AddWithValue("@username", txtUsername.Text)
                    .Parameters.AddWithValue("@password", txtPass.Text)
                    .Parameters.AddWithValue("@birthdate", dtpBirthdate.Value.Date)
                    .Parameters.AddWithValue("@gender", cboGender.SelectedIndex)
                    .Parameters.AddWithValue("@priolevel", cboPriority.SelectedIndex)
                    .Parameters.AddWithValue("@address", txtAddress.Text)
                    .Parameters.AddWithValue("@email", txtEmail.Text)
                    .Parameters.AddWithValue("@contactno", txtContact.Text)
                    .ExecuteNonQuery()

                End With
                con.Close()
                MsgBox("Record has been successfully updated!", vbInformation)
                LoadDataInGrid()

            End If
        Catch ex As Exception
            con.Close()
            MsgBox(ex.Message, vbCritical)
        End Try
    End Sub
    Private Sub LoadDataInGrid()
        Dim con As New SqlConnection("Data Source=ACE\SQLEXPRESS;Initial Catalog=TBVaccineSystem;Integrated Security=True")
        Dim cmd As New SqlCommand("Select * from [dbo].[tblregister]", con)
        Dim sda As New SqlDataAdapter(cmd)
        Dim dt As New DataTable
        sda.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub frmRecord_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadDataInGrid()
    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        'Pag click mo lalabas sa textbox
        Dim con As New SqlConnection("Data Source=ACE\SQLEXPRESS;Initial Catalog=TBVaccineSystem;Integrated Security=True")
        txtRegID.Text = DataGridView1.Rows(e.RowIndex).Cells(0).Value.ToString
        txtLName.Text = DataGridView1.Rows(e.RowIndex).Cells(2).Value.ToString
        txtFname.Text = DataGridView1.Rows(e.RowIndex).Cells(3).Value.ToString
        txtMidIni.Text = DataGridView1.Rows(e.RowIndex).Cells(4).Value.ToString
        txtUsername.Text = DataGridView1.Rows(e.RowIndex).Cells(5).Value.ToString
        txtPass.Text = DataGridView1.Rows(e.RowIndex).Cells(6).Value.ToString
        txtAddress.Text = DataGridView1.Rows(e.RowIndex).Cells(10).Value.ToString
        txtEmail.Text = DataGridView1.Rows(e.RowIndex).Cells(11).Value.ToString
        txtContact.Text = DataGridView1.Rows(e.RowIndex).Cells(12).Value.ToString


        Dim priolevel As String = DataGridView1.Rows(e.RowIndex).Cells(9).Value.ToString
        Dim da As New SqlDataAdapter("SELECT * FROM [dbo].[tblregister] WHERE priolevel = '" & priolevel & "'", con)
        Dim dset = New DataSet
        da.Fill(dset, "[dbo].[tblregister]")
        cboPriority.Text = dset.Tables("[dbo].[tblregister]").Rows(0).Item("priolevel")
        cboGender.Text = dset.Tables("[dbo].[tblregister]").Rows(0).Item("gender")
        cboTypeID.Text = dset.Tables("[dbo].[tblregister]").Rows(0).Item("idtype")
    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged
        da = New SqlDataAdapter("SELECT * FROM [dbo].[tblregister] WHERE regisid Like '%" & txtSearch.Text & "' OR lastname Like '%" & txtSearch.Text & "%'", con)
        dset = New DataSet
        da.Fill(dset, "[dbo].[tblregister]")
        DataGridView1.DataSource = dset.Tables("[dbo].[tblregister]").DefaultView
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim RegisID As String = txtRegID.Text
        Dim con As New SqlConnection("Data Source=ACE\SQLEXPRESS;Initial Catalog=TBVaccineSystem;Integrated Security=True")

        con.Open()
        Dim cmd As New SqlCommand("DELETE from [dbo].[tblregister] WHERE regisid=" & txtRegID.Text & ",", con)
        cmd.ExecuteNonQuery()
        MessageBox.Show("You successfully deleted data!", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Information)
        LoadDataInGrid()
        con.Close()
    End Sub
End Class