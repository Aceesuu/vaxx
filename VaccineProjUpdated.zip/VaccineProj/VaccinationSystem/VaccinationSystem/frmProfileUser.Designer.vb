﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmProfileUser
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmProfileUser))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnLogout = New System.Windows.Forms.Button()
        Me.btnPersonal = New System.Windows.Forms.Button()
        Me.btnAppoint = New System.Windows.Forms.Button()
        Me.btnRecord = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.Panel1.Controls.Add(Me.btnLogout)
        Me.Panel1.Controls.Add(Me.btnPersonal)
        Me.Panel1.Controls.Add(Me.btnAppoint)
        Me.Panel1.Controls.Add(Me.btnRecord)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(225, 723)
        Me.Panel1.TabIndex = 0
        '
        'btnLogout
        '
        Me.btnLogout.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnLogout.FlatAppearance.BorderSize = 0
        Me.btnLogout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(132, Byte), Integer), CType(CType(227, Byte), Integer))
        Me.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLogout.ForeColor = System.Drawing.Color.White
        Me.btnLogout.Image = CType(resources.GetObject("btnLogout.Image"), System.Drawing.Image)
        Me.btnLogout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnLogout.Location = New System.Drawing.Point(6, 669)
        Me.btnLogout.Name = "btnLogout"
        Me.btnLogout.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.btnLogout.Size = New System.Drawing.Size(216, 38)
        Me.btnLogout.TabIndex = 15
        Me.btnLogout.Text = "  LOGOUT"
        Me.btnLogout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnLogout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnLogout.UseVisualStyleBackColor = True
        '
        'btnPersonal
        '
        Me.btnPersonal.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnPersonal.FlatAppearance.BorderSize = 0
        Me.btnPersonal.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(132, Byte), Integer), CType(CType(227, Byte), Integer))
        Me.btnPersonal.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPersonal.Font = New System.Drawing.Font("Lucida Sans", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPersonal.ForeColor = System.Drawing.Color.White
        Me.btnPersonal.Image = CType(resources.GetObject("btnPersonal.Image"), System.Drawing.Image)
        Me.btnPersonal.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnPersonal.Location = New System.Drawing.Point(0, 235)
        Me.btnPersonal.Name = "btnPersonal"
        Me.btnPersonal.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.btnPersonal.Size = New System.Drawing.Size(213, 38)
        Me.btnPersonal.TabIndex = 10
        Me.btnPersonal.Text = "  PERSONAL DETAILS"
        Me.btnPersonal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnPersonal.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnPersonal.UseVisualStyleBackColor = True
        '
        'btnAppoint
        '
        Me.btnAppoint.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnAppoint.FlatAppearance.BorderSize = 0
        Me.btnAppoint.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(132, Byte), Integer), CType(CType(227, Byte), Integer))
        Me.btnAppoint.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAppoint.ForeColor = System.Drawing.Color.White
        Me.btnAppoint.Image = CType(resources.GetObject("btnAppoint.Image"), System.Drawing.Image)
        Me.btnAppoint.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnAppoint.Location = New System.Drawing.Point(0, 323)
        Me.btnAppoint.Name = "btnAppoint"
        Me.btnAppoint.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.btnAppoint.Size = New System.Drawing.Size(216, 38)
        Me.btnAppoint.TabIndex = 12
        Me.btnAppoint.Text = "  APPOINMENT"
        Me.btnAppoint.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnAppoint.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnAppoint.UseVisualStyleBackColor = True
        '
        'btnRecord
        '
        Me.btnRecord.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnRecord.FlatAppearance.BorderSize = 0
        Me.btnRecord.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(132, Byte), Integer), CType(CType(227, Byte), Integer))
        Me.btnRecord.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRecord.ForeColor = System.Drawing.Color.White
        Me.btnRecord.Image = CType(resources.GetObject("btnRecord.Image"), System.Drawing.Image)
        Me.btnRecord.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnRecord.Location = New System.Drawing.Point(0, 279)
        Me.btnRecord.Name = "btnRecord"
        Me.btnRecord.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.btnRecord.Size = New System.Drawing.Size(210, 38)
        Me.btnRecord.TabIndex = 14
        Me.btnRecord.Text = "  VACCINE RECORD"
        Me.btnRecord.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnRecord.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnRecord.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.AutoSize = True
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(7, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(195, Byte), Integer))
        Me.Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), System.Drawing.Image)
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(225, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1257, 723)
        Me.Panel2.TabIndex = 1
        '
        'frmProfileUser
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 19.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(179, Byte), Integer), CType(CType(196, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1482, 723)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Lucida Sans", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmProfileUser"
        Me.Text = "frmProfile"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents btnLogout As Button
    Friend WithEvents btnPersonal As Button
    Friend WithEvents btnAppoint As Button
    Friend WithEvents btnRecord As Button
End Class
