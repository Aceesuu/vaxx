﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmProfileAdmin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmProfileAdmin))
        Me.btnFacility = New System.Windows.Forms.Button()
        Me.btnRecord = New System.Windows.Forms.Button()
        Me.btnVaccinator = New System.Windows.Forms.Button()
        Me.btnVaccineBrand = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnLogout = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnAudit = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnFacility
        '
        Me.btnFacility.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnFacility.FlatAppearance.BorderSize = 0
        Me.btnFacility.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(132, Byte), Integer), CType(CType(227, Byte), Integer))
        Me.btnFacility.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnFacility.ForeColor = System.Drawing.Color.White
        Me.btnFacility.Image = CType(resources.GetObject("btnFacility.Image"), System.Drawing.Image)
        Me.btnFacility.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnFacility.Location = New System.Drawing.Point(0, 338)
        Me.btnFacility.Margin = New System.Windows.Forms.Padding(4)
        Me.btnFacility.Name = "btnFacility"
        Me.btnFacility.Padding = New System.Windows.Forms.Padding(12, 0, 0, 0)
        Me.btnFacility.Size = New System.Drawing.Size(221, 45)
        Me.btnFacility.TabIndex = 16
        Me.btnFacility.Text = "  FACILITY"
        Me.btnFacility.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnFacility.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnFacility.UseVisualStyleBackColor = True
        '
        'btnRecord
        '
        Me.btnRecord.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnRecord.FlatAppearance.BorderSize = 0
        Me.btnRecord.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(132, Byte), Integer), CType(CType(227, Byte), Integer))
        Me.btnRecord.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRecord.Font = New System.Drawing.Font("Lucida Sans", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRecord.ForeColor = System.Drawing.Color.White
        Me.btnRecord.Image = CType(resources.GetObject("btnRecord.Image"), System.Drawing.Image)
        Me.btnRecord.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnRecord.Location = New System.Drawing.Point(4, 169)
        Me.btnRecord.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRecord.Name = "btnRecord"
        Me.btnRecord.Padding = New System.Windows.Forms.Padding(12, 0, 0, 0)
        Me.btnRecord.Size = New System.Drawing.Size(221, 45)
        Me.btnRecord.TabIndex = 10
        Me.btnRecord.Text = "  RECORD"
        Me.btnRecord.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnRecord.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnRecord.UseVisualStyleBackColor = True
        '
        'btnVaccinator
        '
        Me.btnVaccinator.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnVaccinator.FlatAppearance.BorderSize = 0
        Me.btnVaccinator.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(132, Byte), Integer), CType(CType(227, Byte), Integer))
        Me.btnVaccinator.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnVaccinator.ForeColor = System.Drawing.Color.White
        Me.btnVaccinator.Image = CType(resources.GetObject("btnVaccinator.Image"), System.Drawing.Image)
        Me.btnVaccinator.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnVaccinator.Location = New System.Drawing.Point(0, 274)
        Me.btnVaccinator.Margin = New System.Windows.Forms.Padding(4)
        Me.btnVaccinator.Name = "btnVaccinator"
        Me.btnVaccinator.Padding = New System.Windows.Forms.Padding(12, 0, 0, 0)
        Me.btnVaccinator.Size = New System.Drawing.Size(221, 45)
        Me.btnVaccinator.TabIndex = 12
        Me.btnVaccinator.Text = "  VACCINATOR"
        Me.btnVaccinator.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnVaccinator.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnVaccinator.UseVisualStyleBackColor = True
        '
        'btnVaccineBrand
        '
        Me.btnVaccineBrand.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnVaccineBrand.FlatAppearance.BorderSize = 0
        Me.btnVaccineBrand.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(132, Byte), Integer), CType(CType(227, Byte), Integer))
        Me.btnVaccineBrand.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnVaccineBrand.ForeColor = System.Drawing.Color.White
        Me.btnVaccineBrand.Image = CType(resources.GetObject("btnVaccineBrand.Image"), System.Drawing.Image)
        Me.btnVaccineBrand.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnVaccineBrand.Location = New System.Drawing.Point(0, 221)
        Me.btnVaccineBrand.Margin = New System.Windows.Forms.Padding(4)
        Me.btnVaccineBrand.Name = "btnVaccineBrand"
        Me.btnVaccineBrand.Padding = New System.Windows.Forms.Padding(12, 0, 0, 0)
        Me.btnVaccineBrand.Size = New System.Drawing.Size(221, 45)
        Me.btnVaccineBrand.TabIndex = 14
        Me.btnVaccineBrand.Text = "  VACCINE BRAND"
        Me.btnVaccineBrand.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnVaccineBrand.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnVaccineBrand.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.Panel1.Controls.Add(Me.btnAudit)
        Me.Panel1.Controls.Add(Me.btnLogout)
        Me.Panel1.Controls.Add(Me.btnFacility)
        Me.Panel1.Controls.Add(Me.btnRecord)
        Me.Panel1.Controls.Add(Me.btnVaccineBrand)
        Me.Panel1.Controls.Add(Me.btnVaccinator)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(225, 723)
        Me.Panel1.TabIndex = 17
        '
        'btnLogout
        '
        Me.btnLogout.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnLogout.FlatAppearance.BorderSize = 0
        Me.btnLogout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(132, Byte), Integer), CType(CType(227, Byte), Integer))
        Me.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLogout.ForeColor = System.Drawing.Color.White
        Me.btnLogout.Image = CType(resources.GetObject("btnLogout.Image"), System.Drawing.Image)
        Me.btnLogout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnLogout.Location = New System.Drawing.Point(6, 669)
        Me.btnLogout.Name = "btnLogout"
        Me.btnLogout.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.btnLogout.Size = New System.Drawing.Size(216, 38)
        Me.btnLogout.TabIndex = 15
        Me.btnLogout.Text = "  LOGOUT"
        Me.btnLogout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnLogout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnLogout.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.AutoSize = True
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(7, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(195, Byte), Integer))
        Me.Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), System.Drawing.Image)
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(225, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1257, 723)
        Me.Panel2.TabIndex = 18
        '
        'btnAudit
        '
        Me.btnAudit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnAudit.FlatAppearance.BorderSize = 0
        Me.btnAudit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(9, Byte), Integer), CType(CType(132, Byte), Integer), CType(CType(227, Byte), Integer))
        Me.btnAudit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAudit.ForeColor = System.Drawing.Color.White
        Me.btnAudit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnAudit.Location = New System.Drawing.Point(4, 402)
        Me.btnAudit.Margin = New System.Windows.Forms.Padding(4)
        Me.btnAudit.Name = "btnAudit"
        Me.btnAudit.Padding = New System.Windows.Forms.Padding(12, 0, 0, 0)
        Me.btnAudit.Size = New System.Drawing.Size(221, 45)
        Me.btnAudit.TabIndex = 17
        Me.btnAudit.Text = "    AUDIT TRAIL"
        Me.btnAudit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnAudit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnAudit.UseVisualStyleBackColor = True
        '
        'frmProfileAdmin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 19.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1482, 723)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Lucida Sans", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmProfileAdmin"
        Me.Text = "frmProfileAdmin"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnFacility As Button
    Friend WithEvents btnRecord As Button
    Friend WithEvents btnVaccinator As Button
    Friend WithEvents btnVaccineBrand As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents btnLogout As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents btnAudit As Button
End Class
