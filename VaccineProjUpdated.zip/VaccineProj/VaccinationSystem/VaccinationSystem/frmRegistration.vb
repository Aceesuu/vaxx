﻿Imports System.Data
Imports System.Data.SqlClient

Public Class frmRegistration
    Dim con As SqlConnection
    Dim cmd As SqlCommand
    Dim usernameTest As String
    Dim regisId As Integer
    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click
        Dim conn As SqlConnection = New SqlConnection("Data Source=ACE\SQLEXPRESS;Initial Catalog=TBVaccineSystem;Integrated Security=True")
        Dim searchUsername As SqlCommand = New SqlCommand("SELECT [username] FROM [dbo].[tblregister] WHERE [username] = '" + txtUsername.Text + "'", conn)


        conn.Open()

        usernameTest = searchUsername.ExecuteScalar

        searchUsername.ExecuteNonQuery()
        conn.Close()

        If txtUsername.Text = usernameTest Then
            MessageBox.Show("USERNAME IS ALREADY TAKEN!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else

            Dim con As New SqlConnection("Data Source=ACE\SQLEXPRESS;Initial Catalog=TBVaccineSystem;Integrated Security=True")
            Dim cmd As New SqlCommand("INSERT INTO [dbo].[tblregister]
            
            ([idtype]
           ,[lastname]
           ,[firstname]
           ,[middleini]
           ,[username]
           ,[password]
           ,[birthdate]
           ,[gender]
           ,[priolevel]
           ,[address]
           ,[email]
           ,[contactno])
     VALUES
      ('" + cboTypeID.SelectedItem.ToString + "','" + txtLName.Text + "','" + txtFname.Text + "','" + txtMidIni.Text + "','" + txtUsername.Text + "','" + txtPass.Text + "','" + dtpBirthdate.Value.Date + "','" + cboGender.SelectedItem.ToString + "','" + cboPriority.SelectedItem.ToString + "','" + txtAddress.Text + "','" + txtEmail.Text + "','" + TxtContact.Text + "')", con)
            con.Open()
            cmd.ExecuteNonQuery()
            MessageBox.Show("You are now REGISTERED!", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Information)
            con.Close()

            Dim confirmation As DialogResult = MessageBox.Show("Generate registration id to proceed to next step.", "title", MessageBoxButtons.OK, MessageBoxIcon.Information)
            If confirmation = DialogResult.OK Then
                btnGet.Enabled = True
            Else
                btnGet.Enabled = False
            End If

            'Validate Password
            'If ValidatePassword(txtPassword) = False Then
            'MessageBox.Show("Password must have 8 - 15 characters long with at least one numeric character and uppercase, lowercase and special characters!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)

            'Else
            'MessageBox.Show("GOOD PASSWORD!", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Information)
            'End If


        End If


    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub btnGet_Click(sender As Object, e As EventArgs) Handles btnGet.Click
        Dim conn As SqlConnection = New SqlConnection("Data Source=ACE\SQLEXPRESS;Initial Catalog=TBVaccineSystem;Integrated Security=True")
        Dim cmd As SqlCommand = New SqlCommand("SELECT [regisid] FROM [dbo].[tblregister] WHERE [username] COLLATE SQL_Latin1_General_CP1_CS_AS = '" + txtUsername.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS ", conn)


        conn.Open()

        regisId = cmd.ExecuteScalar
        txtReg.Text = regisId

        cmd.ExecuteNonQuery()
        conn.Close()
        Dim ques As DialogResult = MessageBox.Show("Please write down your Regis ID.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
        If ques = DialogResult.OK Then
            Me.Hide()
            frmLogin.Show()
        End If


    End Sub

    Private Sub tmr_Tick(ByVal sender As System.Object, e As System.EventArgs) Handles tmr.Tick
        lblTime.Text = DateTime.Now
        dtpBirthdate.MaxDate = DateTime.Today
        If cboTypeID.SelectedIndex = -1 Or txtFname.Text = "" Or txtLName.Text = "" Or dtpBirthdate.Value = DateTime.Today Or cboGender.SelectedIndex = -1 Or cboPriority.SelectedIndex = -1 Or
          txtAddress.Text = "" Or TxtContact.Text = "" Or txtUsername.Text = "" Or txtPass.Text = "" Or TxtContact.Text.Length < 11 Then
            btnRegister.Enabled = False

        Else
            btnRegister.Enabled = True
        End If
    End Sub
    Private Function ValidatePassword(ByVal Password) As Boolean

        Dim regEx
        regEx = CreateObject("vbscript.regexp")
        regEx.Pattern = "^.*(?=.{8,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&+=]).*$"

        ValidatePassword = regEx.Test(Password)

        regEx = Nothing
    End Function
End Class